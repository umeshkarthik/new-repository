﻿// Defining angularjs module
var app = angular.module('demoModule', []);

// Defining angularjs Controller and injecting ProductsService
app.controller('demoCtrl', function ($scope, $http, ProductsService) {

    $scope.productsData = null;
    // Fetching records from the factory created at the bottom of the script file
    ProductsService.GetAllRecords().then(function (d) {
        $scope.productsData = d.data; // Success
    }, function (response) {
        //debugger;
        alert('Error Occured !!!'); // Failed
    });

    // Calculate Total of Price After Initialization
    //$scope.total = function () {
    //    var total = 0;
    //    angular.forEach($scope.productsData, function (item) {
    //        total += item.Price;
    //    })
    //    return total;
    //}

    $scope.Product = {
        PkCId: '',
        FirstName: '',
        LastName: '',
        Email: '',
        IsActive: '',
        PhoneNumber:''
    };

    // Reset product details
    $scope.clear = function () {
        $scope.Product.PkCId = '';
        $scope.Product.FirstName = '';
        $scope.Product.LastName = '';
        $scope.Product.Email = '';
        $scope.Product.IsActive = '';
        $scope.Product.PhoneNumber = '';
    }

    //Add New Item
    $scope.save = function () {
        if ($scope.Product.FirstName != "" &&
       $scope.Product.LastName != "" && $scope.Product.Email != "" && $scope.Product.IsActive != "" && $scope.Product.PhoneNumber != "") {
            // Call Http request using $.ajax

            //$.ajax({
            //    type: 'POST',
            //    contentType: 'application/json; charset=utf-8',
            //    data: JSON.stringify($scope.Product),
            //    url: 'api/Product/PostProduct',
            //    success: function (data, status) {
            //        $scope.$apply(function () {
            //            $scope.productsData.push(data);
            //            alert("Product Added Successfully !!!");
            //            $scope.clear();
            //        });
            //    },
            //    error: function (status) { }
            //});

            // or you can call Http request using $http
            //debugger;
            $http({
                method: 'POST',
                url: '/api/Contact/Post/',
                data: $scope.Product
            }).then(function successCallback(response) {
                // this callback will be called asynchronously
                // when the response is available
                $scope.productsData.push(response.data);
                $scope.clear();
                alert("Contact Added Successfully !!!");
            }, function errorCallback(response) {
                //debugger;
                // called asynchronously if an error occurs
                // or server returns response with an error status.
                alert("Error : " + response.data.ExceptionMessage);
            });
        }
        else {
            alert('Please Enter All the Values !!');
        }
    };

    // Edit product details
    $scope.edit = function (data) {
        //debugger;
        $scope.Product = { PkCId: data.PkCId, FirstName: data.FirstName, LastName: data.LastName, Email: data.Email, PhoneNumber: data.PhoneNumber, IsActive: data.IsActive };
    }

    // Cancel product details
    $scope.cancel = function () {
        $scope.clear();
    }

    // Update product details
    $scope.update = function () {
        //debugger;
        if ($scope.Product.FirstName != "" &&
       $scope.Product.LastName != "" && $scope.Product.Email != ""  && $scope.Product.PhoneNumber != "") {
            $http({
                method: 'POST',
                url: '/api/Contact/Update/?PkCId=' + $scope.Product.PkCId,
                data: $scope.Product,
                contentType: false
            }).then(function successCallback(response) {
                //debugger;
                $scope.productsData = response.data;
                $scope.clear();
                alert("Contact Updated Successfully !!!");
            }, function errorCallback(response) {
                //debugger;
                alert("Error : " + response.data.ExceptionMessage);
            });
        }
        else {
            alert('Please Enter All the Values !!');
        }
    };

    // Delete product details
    $scope.delete = function (index) {
        //debugger;
        $http({
            method: 'DELETE',
          
            url: '/api/Contact/Remove/?PkCId=' + $scope.productsData[index].PkCId,
            contentType: false,
        }).then(function successCallback(response) {
            $scope.productsData.splice(index, 1);
            alert("Contact Deleted Successfully !!!");
        }, function errorCallback(response) {

            alert("Error : " + response.data.ExceptionMessage);
        });
    };

});

// Here I have created a factory which is a populer way to create and configure services. You may also create the factories in another script file which is best practice.
// You can also write above codes for POST,PUT,DELETE in this factory instead of controller, so that our controller will look clean and exhibits proper Separation of Concern.
app.factory('ProductsService', function ($http) {
    var fac = {};
    fac.GetAllRecords = function () {
        //debugger;
        return $http.get('/api/Contact/GetAll');
    }
    return fac;
});