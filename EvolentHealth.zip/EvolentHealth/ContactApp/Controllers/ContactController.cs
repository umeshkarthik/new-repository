﻿using ContactApp.Interfaces;
using ContactApp.Models;
using ContactApp.Repositories;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ContactApp.Controllers
{
    public class ContactController : ApiController
    {
        static readonly InContactRepository repository = new ContactRepository();

        public IEnumerable GetAll()
        {
            var result= repository.GetAll();
            return result;
        }

        public Contact Post(Contact item)
        {
            if (item.IsActive==null)
            {
                item.IsActive = false;
            }
            return repository.Add(item);
        }

       // [HttpPut]
        public IEnumerable Update(int PkCId, Contact contact)
        {
            contact.PkCId = PkCId;
            if (repository.Update(contact))
            {
                return repository.GetAll();
            }
            else
            {
                return null;
            }
        }

       [HttpDelete]
        public bool Remove(int PkCId)
        {
            if (repository.Delete(PkCId))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}