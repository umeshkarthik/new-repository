﻿using ContactApp.Interfaces;
using ContactApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ContactApp.Repositories
{
    public class ContactRepository : InContactRepository
    {

        DemoEntities ctx = new DemoEntities();
        public IEnumerable<Models.Contact> GetAll()
        {
            return ctx.Contacts;
        }

        public Models.Contact Get(int id)
        {
            return ctx.Contacts.Find(id);
        }

        public Models.Contact Add(Models.Contact item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }

            // TO DO : Code to save record into database
            ctx.Contacts.Add(item);
            ctx.SaveChanges();
            return item;
        }

        public bool Update(Models.Contact item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }

            // TO DO : Code to update record into database
            var contact = ctx.Contacts.Single(a => a.PkCId == item.PkCId);
            contact.FirstName = item.FirstName;
            contact.LastName = item.LastName;
            contact.Email = item.Email;
            contact.PhoneNumber = item.PhoneNumber;
            contact.IsActive = item.IsActive;
            ctx.SaveChanges();

            return true;
        }

        public bool Delete(int id)
        {
            var item = ctx.Contacts.Find(id);
            ctx.Contacts.Remove(item);
            ctx.SaveChanges();
            return true;
        }
    }
}